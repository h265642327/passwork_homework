#include<bits/stdc++.h>
//你可能没有万能头文件所以还是给你粘贴了一份
#include<cmath>
#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;

double c11;
double m11;
int p, q;
int d;
int e;
int n;
int m;


bool isPrime(int a) {
    if (a == 1) {
        return false;
    }
    for (int i = 2; i <= sqrt(a); i++) {
        if (a % i == 0) {
            return false;
        }
    }
    return true;
}

bool gcd(int a, int b) {
    for (int i = min(a, b); i >= 2; i--) {
        if (a % i == 0 && b % i == 0) {
            return false;
        }
    }
    return true;
}
void encrypt();
void decrypt();
int main()
{
    cout << "请依次输入p和q" << endl;
    cin >> p >> q;
    if (isPrime(p) == false) {
        cout << "p不是素数" << endl;
        return 0;
    }
    if (isPrime(q) == false) {
        cout << "q不是素数" << endl;
        return 0;
    }
    n = q * p;
    m = (q - 1) * (p - 1);
    if (m <= 2) {
        printf("q和p太小了，请重新输入");
        return 0;
    }

    for (int i = m - 1; i > 1; i--) {
        if (gcd(i, m) == true) {
            e = i;
            break;
        }
    }


    int k = 1;
    while ((int)((k * m) + 1) % e != 0) {
        k++;
    }
    d = ((k * m) + 1) / e;


    int choice;
    printf("输入你的选择\n");
    printf("1：加密\n");
    printf("2：解密\n");
    cin >> choice;
    switch (choice) {
    case 1:
        printf("输入你的原文\n");
        cin >> m11;
        encrypt();
        break;
    case 2:
        printf("输入你的密文\n");
        cin >> c11;
        decrypt();
        break;
    }
    return 0;
}


void encrypt() {
    c11 = (int)(pow(m11*1.0, e)) % n;
    cout << "加密成功：" << c11 << endl;
}

void decrypt() {
    m11 = (int)(pow(c11*1.0, d)) % n;
    cout << "解密成功：" << m11 << endl;
}